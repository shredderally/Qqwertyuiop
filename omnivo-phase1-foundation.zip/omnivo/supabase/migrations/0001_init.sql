-- =====================================================================
-- OMNIVO — Platform Schema
-- Postgres 15+ / Supabase
--
-- Covers the full data model in one migration (22 tables) so later
-- feature phases (dashboard, print center, billing, admin panel) build
-- on top of this without re-migrating core structure.
--
-- Two things are intentionally left unset rather than faked:
--   1. Pro plan pricing (seeded at 0 — see PLAN SEED DATA)
--   2. Theme color/font tokens (seeded empty — see THEME SEED DATA)
-- Both require real decisions, not invented numbers.
-- =====================================================================

create extension if not exists pgcrypto;

-- =====================================================================
-- ENUMS
-- =====================================================================

create type platform_role as enum ('user', 'admin', 'support');
create type business_category as enum (
  'restaurant','cafe','bakery','food_truck',
  'salon','spa','barbershop',
  'retail','hotel','other'
);
create type business_status as enum ('draft', 'published', 'suspended');
create type team_role as enum ('owner', 'manager', 'staff');
create type team_member_status as enum ('invited', 'active', 'removed');
create type item_type as enum ('product', 'service');
create type qr_type as enum ('business', 'table', 'poster', 'sticker');
create type order_status as enum ('pending','confirmed','preparing','ready','completed','cancelled');
create type billing_provider as enum ('stripe', 'paddle');
create type subscription_status as enum ('trialing','active','past_due','canceled','incomplete');
create type analytics_event_type as enum (
  'view','item_view','qr_scan',
  'click_call','click_whatsapp','click_map','click_website'
);
create type ticket_status as enum ('open', 'pending', 'resolved', 'closed');
create type ticket_priority as enum ('low', 'normal', 'high', 'urgent');
create type social_platform as enum ('instagram','facebook','tiktok','twitter','youtube','linkedin');
create type discount_type as enum ('percent', 'fixed');

-- =====================================================================
-- TABLES
-- =====================================================================

-- ---- profiles (extends auth.users) ----
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  avatar_url text,
  platform_role platform_role not null default 'user',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---- plans (Free / Pro definitions) ----
create table public.plans (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  price_monthly numeric(10,2) not null default 0,
  price_yearly numeric(10,2) not null default 0,
  max_businesses integer,              -- null = unlimited
  max_products_per_business integer,   -- null = unlimited
  max_staff_per_business integer,      -- null = unlimited
  custom_branding boolean not null default false,
  premium_themes boolean not null default false,
  analytics_enabled boolean not null default false,
  priority_support boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---- subscriptions (one row = current state per owner, upserted by billing webhook) ----
create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references public.profiles(id) on delete cascade,
  plan_id uuid not null references public.plans(id),
  status subscription_status not null default 'trialing',
  billing_provider billing_provider,
  provider_customer_id text,
  provider_subscription_id text,
  current_period_start timestamptz,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---- themes ----
create table public.themes (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  preview_image_url text,
  color_tokens jsonb not null default '{}'::jsonb,
  font_tokens jsonb not null default '{}'::jsonb,
  is_premium boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---- businesses (the tenant / storefront) ----
create table public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  theme_id uuid references public.themes(id),
  name text not null,
  slug text not null unique,
  category business_category not null,
  status business_status not null default 'draft',
  description text,
  logo_url text,
  cover_image_url text,
  phone text,
  email text,
  whatsapp_number text,
  website_url text,
  address text,
  latitude numeric(9,6),
  longitude numeric(9,6),
  currency text not null default 'USD',
  timezone text not null default 'UTC',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.business_hours (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  day_of_week smallint not null check (day_of_week between 0 and 6),
  open_time time,
  close_time time,
  is_closed boolean not null default false,
  unique (business_id, day_of_week)
);

create table public.business_social_links (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  platform social_platform not null,
  url text not null,
  unique (business_id, platform)
);

-- ---- team_members (owner auto-enrolled via trigger below) ----
create table public.team_members (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  invited_email text,
  role team_role not null default 'staff',
  status team_member_status not null default 'invited',
  invited_at timestamptz not null default now(),
  joined_at timestamptz,
  unique (business_id, user_id)
);

-- ---- catalog ----
create table public.item_categories (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.catalog_items (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  category_id uuid references public.item_categories(id) on delete set null,
  item_type item_type not null default 'product',
  name text not null,
  description text,
  price numeric(10,2) not null,
  discount_price numeric(10,2),
  is_available boolean not null default true,
  is_hidden boolean not null default false,
  is_featured boolean not null default false,
  is_popular boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.item_images (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.catalog_items(id) on delete cascade,
  image_url text not null,
  sort_order integer not null default 0,
  is_primary boolean not null default false
);

create table public.item_variants (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.catalog_items(id) on delete cascade,
  name text not null,           -- e.g. "Size"
  value text not null,          -- e.g. "Large"
  price_modifier numeric(10,2) not null default 0,
  sort_order integer not null default 0
);

create table public.item_addons (
  id uuid primary key default gen_random_uuid(),
  item_id uuid not null references public.catalog_items(id) on delete cascade,
  name text not null,
  price numeric(10,2) not null default 0,
  is_required boolean not null default false,
  max_selectable integer not null default 1,
  sort_order integer not null default 0
);

create table public.media_library (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  uploaded_by uuid references public.profiles(id) on delete set null,
  file_url text not null,
  file_type text not null,
  file_name text not null,
  file_size_bytes bigint,
  created_at timestamptz not null default now()
);

-- ---- QR system (PNG/SVG/PDF and print-center layouts are render-time
--      outputs of this row, not separate stored entities) ----
create table public.qr_codes (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  type qr_type not null default 'business',
  label text,                    -- e.g. "Table 4"
  target_url text not null,
  design_config jsonb not null default '{}'::jsonb,  -- colors, embedded logo, style
  created_at timestamptz not null default now()
);

-- ---- orders (guest checkout: no customer account required) ----
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  order_number text not null,
  customer_name text,
  customer_phone text,
  table_number text,
  status order_status not null default 'pending',
  subtotal numeric(10,2) not null default 0,
  total numeric(10,2) not null default 0,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id, order_number)
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  catalog_item_id uuid references public.catalog_items(id) on delete set null,
  item_name_snapshot text not null,   -- preserves order history if item is later edited/deleted
  unit_price numeric(10,2) not null,
  quantity integer not null default 1,
  selected_variants jsonb not null default '[]'::jsonb,
  selected_addons jsonb not null default '[]'::jsonb,
  line_total numeric(10,2) not null
);

create table public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type discount_type not null,
  discount_value numeric(10,2) not null,
  applicable_plan_id uuid references public.plans(id),
  max_uses integer,
  used_count integer not null default 0,
  valid_from timestamptz not null default now(),
  valid_until timestamptz,
  created_at timestamptz not null default now()
);

create table public.analytics_events (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  item_id uuid references public.catalog_items(id) on delete set null,
  event_type analytics_event_type not null,
  visitor_id text,     -- anonymous session id, set client-side
  country text,
  device_type text,
  referrer text,
  created_at timestamptz not null default now()
);

create table public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  business_id uuid references public.businesses(id) on delete set null,
  subject text not null,
  status ticket_status not null default 'open',
  priority ticket_priority not null default 'normal',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.support_ticket_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  message text not null,
  created_at timestamptz not null default now()
);

create table public.feature_flags (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  description text,
  is_enabled_globally boolean not null default false,
  enabled_plan_ids uuid[] not null default '{}',
  created_at timestamptz not null default now()
);

-- =====================================================================
-- INDEXES
-- =====================================================================

create index idx_businesses_owner on public.businesses(owner_id);
create index idx_businesses_status on public.businesses(status);
create index idx_team_members_business on public.team_members(business_id);
create index idx_team_members_user on public.team_members(user_id);
create index idx_item_categories_business on public.item_categories(business_id);
create index idx_catalog_items_business on public.catalog_items(business_id);
create index idx_catalog_items_category on public.catalog_items(category_id);
create index idx_item_images_item on public.item_images(item_id);
create index idx_item_variants_item on public.item_variants(item_id);
create index idx_item_addons_item on public.item_addons(item_id);
create index idx_media_library_business on public.media_library(business_id);
create index idx_qr_codes_business on public.qr_codes(business_id);
create index idx_orders_business_status on public.orders(business_id, status);
create index idx_order_items_order on public.order_items(order_id);
create index idx_analytics_business_created on public.analytics_events(business_id, created_at desc);
create index idx_analytics_event_type on public.analytics_events(business_id, event_type);
create index idx_subscriptions_owner on public.subscriptions(owner_id);
create index idx_support_tickets_user on public.support_tickets(user_id);
create index idx_ticket_messages_ticket on public.support_ticket_messages(ticket_id);

-- =====================================================================
-- TRIGGER FUNCTIONS
-- =====================================================================

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger trg_businesses_updated_at before update on public.businesses for each row execute function public.set_updated_at();
create trigger trg_catalog_items_updated_at before update on public.catalog_items for each row execute function public.set_updated_at();
create trigger trg_orders_updated_at before update on public.orders for each row execute function public.set_updated_at();
create trigger trg_subscriptions_updated_at before update on public.subscriptions for each row execute function public.set_updated_at();
create trigger trg_support_tickets_updated_at before update on public.support_tickets for each row execute function public.set_updated_at();

-- New auth.users row -> profiles row
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data ->> 'full_name');
  return new;
end;
$$;

create trigger trg_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- New business -> owner auto-enrolled as a team member.
-- Keeps every RLS check reducible to "is a team member" with no
-- separate owner_id special-casing.
create or replace function public.handle_new_business()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.team_members (business_id, user_id, role, status, joined_at)
  values (new.id, new.owner_id, 'owner', 'active', now());
  return new;
end;
$$;

create trigger trg_business_owner_membership
after insert on public.businesses
for each row execute function public.handle_new_business();

-- =====================================================================
-- RLS HELPER FUNCTIONS
-- =====================================================================

create or replace function public.is_platform_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and platform_role in ('admin', 'support')
  );
$$;

create or replace function public.is_business_member(target_business_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.team_members
    where business_id = target_business_id
      and user_id = auth.uid()
      and status = 'active'
  );
$$;

create or replace function public.is_business_manager(target_business_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.team_members
    where business_id = target_business_id
      and user_id = auth.uid()
      and status = 'active'
      and role in ('owner', 'manager')
  );
$$;

create or replace function public.is_business_published(target_business_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.businesses
    where id = target_business_id and status = 'published'
  );
$$;

-- =====================================================================
-- ROW LEVEL SECURITY
-- =====================================================================

alter table public.profiles enable row level security;
alter table public.plans enable row level security;
alter table public.subscriptions enable row level security;
alter table public.themes enable row level security;
alter table public.businesses enable row level security;
alter table public.business_hours enable row level security;
alter table public.business_social_links enable row level security;
alter table public.team_members enable row level security;
alter table public.item_categories enable row level security;
alter table public.catalog_items enable row level security;
alter table public.item_images enable row level security;
alter table public.item_variants enable row level security;
alter table public.item_addons enable row level security;
alter table public.media_library enable row level security;
alter table public.qr_codes enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.coupons enable row level security;
alter table public.analytics_events enable row level security;
alter table public.support_tickets enable row level security;
alter table public.support_ticket_messages enable row level security;
alter table public.feature_flags enable row level security;

-- profiles
create policy "profiles_select_own_or_admin" on public.profiles for select
  using (id = auth.uid() or public.is_platform_admin());
create policy "profiles_update_own" on public.profiles for update
  using (id = auth.uid()) with check (id = auth.uid());

-- plans (public reference data)
create policy "plans_select_all" on public.plans for select using (true);
create policy "plans_admin_write" on public.plans for all
  using (public.is_platform_admin()) with check (public.is_platform_admin());

-- subscriptions (writes happen via billing webhook using the service role, which bypasses RLS)
create policy "subscriptions_select_own_or_admin" on public.subscriptions for select
  using (owner_id = auth.uid() or public.is_platform_admin());
create policy "subscriptions_admin_write" on public.subscriptions for all
  using (public.is_platform_admin()) with check (public.is_platform_admin());

-- themes (public reference data)
create policy "themes_select_all" on public.themes for select using (true);
create policy "themes_admin_write" on public.themes for all
  using (public.is_platform_admin()) with check (public.is_platform_admin());

-- businesses
create policy "businesses_public_read_published" on public.businesses for select
  using (status = 'published' or public.is_business_member(id) or public.is_platform_admin());
create policy "businesses_insert_own" on public.businesses for insert
  with check (owner_id = auth.uid());
create policy "businesses_update_managers" on public.businesses for update
  using (public.is_business_manager(id) or public.is_platform_admin())
  with check (public.is_business_manager(id) or public.is_platform_admin());
create policy "businesses_delete_owner" on public.businesses for delete
  using (owner_id = auth.uid() or public.is_platform_admin());

-- business_hours / business_social_links (public if business is published)
create policy "business_hours_read" on public.business_hours for select
  using (public.is_business_published(business_id) or public.is_business_member(business_id) or public.is_platform_admin());
create policy "business_hours_write" on public.business_hours for all
  using (public.is_business_manager(business_id) or public.is_platform_admin())
  with check (public.is_business_manager(business_id) or public.is_platform_admin());

create policy "social_links_read" on public.business_social_links for select
  using (public.is_business_published(business_id) or public.is_business_member(business_id) or public.is_platform_admin());
create policy "social_links_write" on public.business_social_links for all
  using (public.is_business_manager(business_id) or public.is_platform_admin())
  with check (public.is_business_manager(business_id) or public.is_platform_admin());

-- team_members
create policy "team_members_read" on public.team_members for select
  using (public.is_business_member(business_id) or public.is_platform_admin());
create policy "team_members_manage" on public.team_members for all
  using (public.is_business_manager(business_id) or public.is_platform_admin())
  with check (public.is_business_manager(business_id) or public.is_platform_admin());

-- item_categories (any active team member can manage day-to-day catalog)
create policy "item_categories_read" on public.item_categories for select
  using (public.is_business_published(business_id) or public.is_business_member(business_id) or public.is_platform_admin());
create policy "item_categories_write" on public.item_categories for all
  using (public.is_business_member(business_id) or public.is_platform_admin())
  with check (public.is_business_member(business_id) or public.is_platform_admin());

-- catalog_items (hidden items never show to public storefront visitors)
create policy "catalog_items_public_read" on public.catalog_items for select
  using (
    (public.is_business_published(business_id) and is_hidden = false)
    or public.is_business_member(business_id)
    or public.is_platform_admin()
  );
create policy "catalog_items_write" on public.catalog_items for all
  using (public.is_business_member(business_id) or public.is_platform_admin())
  with check (public.is_business_member(business_id) or public.is_platform_admin());

-- item_images / item_variants / item_addons (join through catalog_items)
create policy "item_images_read" on public.item_images for select
  using (exists (
    select 1 from public.catalog_items ci where ci.id = item_images.item_id
      and ((public.is_business_published(ci.business_id) and ci.is_hidden = false)
        or public.is_business_member(ci.business_id) or public.is_platform_admin())
  ));
create policy "item_images_write" on public.item_images for all
  using (exists (select 1 from public.catalog_items ci where ci.id = item_images.item_id and public.is_business_member(ci.business_id)) or public.is_platform_admin())
  with check (exists (select 1 from public.catalog_items ci where ci.id = item_images.item_id and public.is_business_member(ci.business_id)) or public.is_platform_admin());

create policy "item_variants_read" on public.item_variants for select
  using (exists (
    select 1 from public.catalog_items ci where ci.id = item_variants.item_id
      and ((public.is_business_published(ci.business_id) and ci.is_hidden = false)
        or public.is_business_member(ci.business_id) or public.is_platform_admin())
  ));
create policy "item_variants_write" on public.item_variants for all
  using (exists (select 1 from public.catalog_items ci where ci.id = item_variants.item_id and public.is_business_member(ci.business_id)) or public.is_platform_admin())
  with check (exists (select 1 from public.catalog_items ci where ci.id = item_variants.item_id and public.is_business_member(ci.business_id)) or public.is_platform_admin());

create policy "item_addons_read" on public.item_addons for select
  using (exists (
    select 1 from public.catalog_items ci where ci.id = item_addons.item_id
      and ((public.is_business_published(ci.business_id) and ci.is_hidden = false)
        or public.is_business_member(ci.business_id) or public.is_platform_admin())
  ));
create policy "item_addons_write" on public.item_addons for all
  using (exists (select 1 from public.catalog_items ci where ci.id = item_addons.item_id and public.is_business_member(ci.business_id)) or public.is_platform_admin())
  with check (exists (select 1 from public.catalog_items ci where ci.id = item_addons.item_id and public.is_business_member(ci.business_id)) or public.is_platform_admin());

-- media_library / qr_codes (team-only, never public)
create policy "media_library_team_access" on public.media_library for all
  using (public.is_business_member(business_id) or public.is_platform_admin())
  with check (public.is_business_member(business_id) or public.is_platform_admin());

create policy "qr_codes_team_access" on public.qr_codes for all
  using (public.is_business_member(business_id) or public.is_platform_admin())
  with check (public.is_business_member(business_id) or public.is_platform_admin());

-- orders (guest insert on published businesses; team-only read/update)
create policy "orders_public_insert" on public.orders for insert
  with check (public.is_business_published(business_id));
create policy "orders_team_read" on public.orders for select
  using (public.is_business_member(business_id) or public.is_platform_admin());
create policy "orders_team_update" on public.orders for update
  using (public.is_business_member(business_id) or public.is_platform_admin())
  with check (public.is_business_member(business_id) or public.is_platform_admin());

create policy "order_items_public_insert" on public.order_items for insert
  with check (exists (select 1 from public.orders o where o.id = order_items.order_id and public.is_business_published(o.business_id)));
create policy "order_items_team_read" on public.order_items for select
  using (exists (select 1 from public.orders o where o.id = order_items.order_id and (public.is_business_member(o.business_id) or public.is_platform_admin())));

-- coupons (admin-only table; validate codes server-side via RPC, not direct client select,
-- so the full code list is never exposed to the browser)
create policy "coupons_admin_only" on public.coupons for all
  using (public.is_platform_admin()) with check (public.is_platform_admin());

-- analytics_events (anonymous insert on published businesses; team-only read)
create policy "analytics_public_insert" on public.analytics_events for insert
  with check (public.is_business_published(business_id));
create policy "analytics_team_read" on public.analytics_events for select
  using (public.is_business_member(business_id) or public.is_platform_admin());

-- support_tickets / support_ticket_messages
create policy "support_tickets_owner_read" on public.support_tickets for select
  using (user_id = auth.uid() or public.is_platform_admin());
create policy "support_tickets_owner_insert" on public.support_tickets for insert
  with check (user_id = auth.uid());
create policy "support_tickets_admin_update" on public.support_tickets for update
  using (public.is_platform_admin()) with check (public.is_platform_admin());

create policy "ticket_messages_read" on public.support_ticket_messages for select
  using (exists (select 1 from public.support_tickets t where t.id = support_ticket_messages.ticket_id and (t.user_id = auth.uid() or public.is_platform_admin())));
create policy "ticket_messages_insert" on public.support_ticket_messages for insert
  with check (sender_id = auth.uid() and exists (select 1 from public.support_tickets t where t.id = support_ticket_messages.ticket_id and (t.user_id = auth.uid() or public.is_platform_admin())));

-- feature_flags (admin-only; app resolves gating server-side, not via client read of this table)
create policy "feature_flags_admin_only" on public.feature_flags for all
  using (public.is_platform_admin()) with check (public.is_platform_admin());

-- =====================================================================
-- SEED DATA
-- =====================================================================

-- PLAN SEED DATA — limits match the spec exactly. Prices are left at 0
-- deliberately: real Stripe/Paddle pricing wasn't given, and inventing
-- a number here would be exactly the kind of fake data this schema
-- avoids everywhere else. Update before going live.
insert into public.plans (slug, name, price_monthly, price_yearly, max_businesses, max_products_per_business, max_staff_per_business, custom_branding, premium_themes, analytics_enabled, priority_support)
values
  ('free', 'Free', 0, 0, 1, 20, 1, false, false, false, false),
  ('pro',  'Pro',  0, 0, null, null, null, true, true, true, true);

-- THEME SEED DATA — six themes named in the spec, tokens left empty.
-- Color and font tokens are a real design decision, not schema work.
insert into public.themes (slug, name, is_premium, color_tokens, font_tokens)
values
  ('modern',   'Modern',   false, '{}'::jsonb, '{}'::jsonb),
  ('luxury',   'Luxury',   true,  '{}'::jsonb, '{}'::jsonb),
  ('minimal',  'Minimal',  false, '{}'::jsonb, '{}'::jsonb),
  ('elegant',  'Elegant',  true,  '{}'::jsonb, '{}'::jsonb),
  ('dark',     'Dark',     false, '{}'::jsonb, '{}'::jsonb),
  ('colorful', 'Colorful', false, '{}'::jsonb, '{}'::jsonb);
